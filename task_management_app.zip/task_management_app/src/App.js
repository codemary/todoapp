import React, { Component } from 'react';
import './App.css';
import type {Element as ReactElement } from 'react';
import { findDOMNode } from 'react-dom';
import { Board } from 'react-trello'

// import Data from './data.json';

class App extends Component {

  render() {
    return (
      <div className="App">
        <header className="App-header" style={styles.header}>
          <h1 className="App-title">My Task Handler</h1>
        </header>
        <div className="pt-form-content" style={styles.todoForm}>
          <input id="example-form-group-input-a" className="pt-input" placeholder="Add Project" type="text" dir="auto" />
          <div className="pt-form-helper-text"></div>
        </div>
        <div className="container">
          <div class="row align-items-center">
            <div className="col-md-4" style={styles.columns}>
              <h5 class="mb-1">Todo</h5>
              <ul style={styles.ul}>{listItems}</ul>
            </div>
            <div className="col-md-4" style={styles.columns}>
              <h5 className="mb-1">In Progress</h5>
              <ul style={styles.ul}>
                <li><a>Home</a></li>
                <li><a>News</a></li>
                <li><a>Contact</a></li>
                <li><a>About</a></li>
              </ul>
            </div>
            <div className="col-md-4" style={styles.columns}>
              <h5 className="">Done</h5>
              <ul style={styles.ul}>
                <li><a>Home</a></li>
                <li><a>News</a></li>
                <li><a>Contact</a></li>
                <li><a>About</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div >
    );
  }
}

const handleDragStart = (cardId, laneId) => {
}

const handleDragEnd = (cardId, sourceLaneId, targetLaneId) => {
}

const tasks = [1, 2, 3, 4, 5];
const listItems = tasks.map((tasks) =>
  <li>{tasks}</li>
);

const styles = ({
  header: {
    height: '5',
    backgroundColor: '#D3D3D3',
    fontSize: '3rem',
    color: '$grey',
    marginBottom: '0.5',
    textAlign: 'center',
    fontFamily: 'Merriweather',
    fontSize: 25,
    boxSizing: 'border-box',
  },
  todoForm: {
    width: '40%',
    height: '100',
    marginTop: '5%',
  },
  columns: {
    display: 'inline-block',
    direction: 'flex-row',
    flexDirection: 'column',
    width: '33%',
    height: 100,
    border: 'black',
    borderCollapse: 'collapse',
  },
  ul: {
    listStyleType: 'none',
    width: 100,
    textAlign: 'center',
  }
});

export default App;
